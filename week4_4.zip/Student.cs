﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace week4_4
{
    class Student
    {
        public string Number;
        public string Name;
        public double[] Scores = new double[3];
    }
}
