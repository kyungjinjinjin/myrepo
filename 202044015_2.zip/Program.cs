﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _202044015_2
{
    class Car
    {
        public string CarNumber;
        public DateTime InTime;
        public DateTime OutTime;

        public int ParkingTime()
        {
            return (int)(this.OutTime - this.InTime).TotalMinutes;
        }

        public string PrintState()
        {
            int parkingTime = ParkingTime();
            string message;
            if (parkingTime > 0)
            {
                message = string.Format("[{0}] {1}분 주차", this.CarNumber, parkingTime);
            }
            else
            {
                message = string.Format("[{0}] 주차중", this.CarNumber);
            }
            return message;
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Car car = new Car();

            Console.Write("차량번호:" + car.CarNumber);
            car.CarNumber = Console.ReadLine();

            if (string.IsNullOrWhiteSpace(car.CarNumber))
            {
                Console.WriteLine("차량번호를 제대로 입력해주세요.");
                return;
            }

            try
            {
                Console.Write("입고시간(예:2012/4/3 12:02:03):");
                string In = Console.ReadLine();
                string[] InVal = In.Split(' ');
                car.InTime = DateTime.Parse(InVal[1]);

                string[] InValue = InVal[1].Split(':');
                if (InValue.Length != 3)
                {
                    Console.WriteLine("입고시간이 형식이 잘못되었습니다.");
                    return;
                }

            }
            catch (System.FormatException)
            {
                Console.WriteLine("입고시간이 형식이 잘못되었습니다.");
                return;
            }
            catch (System.IndexOutOfRangeException)
            {
                Console.WriteLine("입고시간이 형식이 잘못되었습니다.");
                return;
            }

            try
            {
                Console.Write("출고시간(예:2012/4/3 14:07:03):");
                string Out = Console.ReadLine();

                if (Out == "")
                {
                    Console.WriteLine(car.PrintState());
                    return;
                }

                string[] OutVal = Out.Split(' ');
                car.OutTime = DateTime.Parse(OutVal[1]);

                string[] OutValue = OutVal[1].Split(':');

                if (OutValue.Length != 3)
                {
                    Console.WriteLine("출고시간이 형식이 잘못되었습니다.");
                    return;
                }

            }
            catch (System.FormatException)
            {
                Console.WriteLine("출고시간이 형식이 잘못되었습니다.");
                return;
            }
            catch (System.IndexOutOfRangeException)
            {
                Console.WriteLine("출고시간이 형식이 잘못되었습니다.");
                return;
            }
            Console.WriteLine(car.PrintState());
        }
    }
}
