﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MyWinForm
{
    public partial class 산술계산기 : Form
    {
        public 산술계산기()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            double opr1 = double.Parse(textBox1.Text);
            double opr2 = double.Parse(textBox2.Text);
            double result = 0;

            string opr = textBox3.Text;
            /*
            switch (opr)
            {
                case "+":
                    result = opr1 + opr2;
                    label1.Text = result.ToString("0.###");
                    break;
                case "-":
                    result = opr1 - opr2;
                    label1.Text = result.ToString("0.###");
                    break;
                case "*":
                    result = opr1 * opr2;
                    label1.Text = result.ToString("0.###");
                    break;
                case "/":
                    result = opr1 / opr2;
                    label1.Text = result.ToString("0.###");
                    break;
                case "%":
                    result = opr1 % opr2;
                    label1.Text = result.ToString("0.###");
                    break;
                default:
                    label1.Text = "계산불가";
                    break;
            }
            */

            if (opr == "+")
            {
                result = opr1 + opr2;
                label1.Text = result.ToString("0.###");

            }
            else if (opr == "-")
            {
                result = opr1 - opr2;
                label1.Text = result.ToString("0.###");
            }
            else if (opr == "*")
            {
                result = opr1 * opr2;
                label1.Text = result.ToString("0.###");
            }
            else if (opr == "/")
            {
                result = opr1 / opr2;
                label1.Text = result.ToString("0.###");
            }
            else if(opr=="%")
            {
                result = opr1 % opr2;
                label1.Text = result.ToString("0.###");
            }
            else
            {
                label1.Text = "계산불가";
            }
            

        }
    }
}
