﻿
namespace School
{
    partial class Form1
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabMain = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.cbxEntranceGrade = new System.Windows.Forms.ComboBox();
            this.btnEntrance = new System.Windows.Forms.Button();
            this.pnlEntranceCompany = new System.Windows.Forms.Panel();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.tbxEntranceCompany = new System.Windows.Forms.Label();
            this.chkIndustrialEdu = new System.Windows.Forms.CheckBox();
            this.tbxEntranceName = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lblEntranceResult = new System.Windows.Forms.Label();
            this.tpgRegCourse = new System.Windows.Forms.TabPage();
            this.tpgSearchStudent = new System.Windows.Forms.TabPage();
            this.label3 = new System.Windows.Forms.Label();
            this.tbxRegCourseSearchId = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.lblRegCourseId = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.lblRegCourseName = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.btnRegCourseSearch = new System.Windows.Forms.Button();
            this.lbxRegCourse = new System.Windows.Forms.ListBox();
            this.tbxRegCourseName = new System.Windows.Forms.TextBox();
            this.btnRegCourseOverriding = new System.Windows.Forms.Button();
            this.btnRegCourseHiding = new System.Windows.Forms.Button();
            this.tabMain.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.pnlEntranceCompany.SuspendLayout();
            this.tpgRegCourse.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabMain
            // 
            this.tabMain.Controls.Add(this.tabPage1);
            this.tabMain.Controls.Add(this.tpgRegCourse);
            this.tabMain.Controls.Add(this.tpgSearchStudent);
            this.tabMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabMain.ItemSize = new System.Drawing.Size(100, 35);
            this.tabMain.Location = new System.Drawing.Point(0, 0);
            this.tabMain.Name = "tabMain";
            this.tabMain.SelectedIndex = 0;
            this.tabMain.Size = new System.Drawing.Size(950, 650);
            this.tabMain.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
            this.tabMain.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.cbxEntranceGrade);
            this.tabPage1.Controls.Add(this.btnEntrance);
            this.tabPage1.Controls.Add(this.pnlEntranceCompany);
            this.tabPage1.Controls.Add(this.chkIndustrialEdu);
            this.tabPage1.Controls.Add(this.tbxEntranceName);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.lblEntranceResult);
            this.tabPage1.Location = new System.Drawing.Point(8, 43);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(934, 599);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "입학관리";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // cbxEntranceGrade
            // 
            this.cbxEntranceGrade.FormattingEnabled = true;
            this.cbxEntranceGrade.Location = new System.Drawing.Point(175, 115);
            this.cbxEntranceGrade.Name = "cbxEntranceGrade";
            this.cbxEntranceGrade.Size = new System.Drawing.Size(247, 32);
            this.cbxEntranceGrade.TabIndex = 5;
            // 
            // btnEntrance
            // 
            this.btnEntrance.Location = new System.Drawing.Point(31, 309);
            this.btnEntrance.Name = "btnEntrance";
            this.btnEntrance.Size = new System.Drawing.Size(516, 41);
            this.btnEntrance.TabIndex = 4;
            this.btnEntrance.Text = "등록";
            this.btnEntrance.UseVisualStyleBackColor = true;
            this.btnEntrance.Click += new System.EventHandler(this.btnEntrance_Click);
            // 
            // pnlEntranceCompany
            // 
            this.pnlEntranceCompany.Controls.Add(this.textBox3);
            this.pnlEntranceCompany.Controls.Add(this.tbxEntranceCompany);
            this.pnlEntranceCompany.Location = new System.Drawing.Point(31, 191);
            this.pnlEntranceCompany.Name = "pnlEntranceCompany";
            this.pnlEntranceCompany.Size = new System.Drawing.Size(516, 81);
            this.pnlEntranceCompany.TabIndex = 3;
            this.pnlEntranceCompany.Visible = false;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(144, 29);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(247, 35);
            this.textBox3.TabIndex = 1;
            // 
            // tbxEntranceCompany
            // 
            this.tbxEntranceCompany.Location = new System.Drawing.Point(-4, 16);
            this.tbxEntranceCompany.Name = "tbxEntranceCompany";
            this.tbxEntranceCompany.Size = new System.Drawing.Size(192, 56);
            this.tbxEntranceCompany.TabIndex = 0;
            this.tbxEntranceCompany.Text = "회사";
            this.tbxEntranceCompany.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.tbxEntranceCompany.Click += new System.EventHandler(this.label1_Click);
            // 
            // chkIndustrialEdu
            // 
            this.chkIndustrialEdu.AutoSize = true;
            this.chkIndustrialEdu.Location = new System.Drawing.Point(457, 120);
            this.chkIndustrialEdu.Name = "chkIndustrialEdu";
            this.chkIndustrialEdu.Size = new System.Drawing.Size(90, 28);
            this.chkIndustrialEdu.TabIndex = 2;
            this.chkIndustrialEdu.Text = "산학";
            this.chkIndustrialEdu.UseVisualStyleBackColor = true;
            this.chkIndustrialEdu.CheckedChanged += new System.EventHandler(this.chkIndustrialEdu_CheckedChanged);
            // 
            // tbxEntranceName
            // 
            this.tbxEntranceName.Location = new System.Drawing.Point(175, 40);
            this.tbxEntranceName.Name = "tbxEntranceName";
            this.tbxEntranceName.Size = new System.Drawing.Size(247, 35);
            this.tbxEntranceName.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(27, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(192, 56);
            this.label1.TabIndex = 0;
            this.label1.Text = "이름";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(27, 105);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(192, 56);
            this.label2.TabIndex = 0;
            this.label2.Text = "학년";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label2.Click += new System.EventHandler(this.label1_Click);
            // 
            // lblEntranceResult
            // 
            this.lblEntranceResult.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.lblEntranceResult.Location = new System.Drawing.Point(3, 374);
            this.lblEntranceResult.Name = "lblEntranceResult";
            this.lblEntranceResult.Padding = new System.Windows.Forms.Padding(10);
            this.lblEntranceResult.Size = new System.Drawing.Size(928, 222);
            this.lblEntranceResult.TabIndex = 0;
            this.lblEntranceResult.Click += new System.EventHandler(this.label1_Click);
            // 
            // tpgRegCourse
            // 
            this.tpgRegCourse.Controls.Add(this.tbxRegCourseName);
            this.tpgRegCourse.Controls.Add(this.lbxRegCourse);
            this.tpgRegCourse.Controls.Add(this.btnRegCourseHiding);
            this.tpgRegCourse.Controls.Add(this.btnRegCourseOverriding);
            this.tpgRegCourse.Controls.Add(this.btnRegCourseSearch);
            this.tpgRegCourse.Controls.Add(this.label8);
            this.tpgRegCourse.Controls.Add(this.lblRegCourseName);
            this.tpgRegCourse.Controls.Add(this.label6);
            this.tpgRegCourse.Controls.Add(this.lblRegCourseId);
            this.tpgRegCourse.Controls.Add(this.label4);
            this.tpgRegCourse.Controls.Add(this.tbxRegCourseSearchId);
            this.tpgRegCourse.Controls.Add(this.label3);
            this.tpgRegCourse.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.tpgRegCourse.Location = new System.Drawing.Point(8, 43);
            this.tpgRegCourse.Name = "tpgRegCourse";
            this.tpgRegCourse.Padding = new System.Windows.Forms.Padding(3);
            this.tpgRegCourse.Size = new System.Drawing.Size(934, 599);
            this.tpgRegCourse.TabIndex = 1;
            this.tpgRegCourse.Text = "수강관리";
            this.tpgRegCourse.UseVisualStyleBackColor = true;
            // 
            // tpgSearchStudent
            // 
            this.tpgSearchStudent.Location = new System.Drawing.Point(8, 43);
            this.tpgSearchStudent.Name = "tpgSearchStudent";
            this.tpgSearchStudent.Padding = new System.Windows.Forms.Padding(3);
            this.tpgSearchStudent.Size = new System.Drawing.Size(934, 599);
            this.tpgSearchStudent.TabIndex = 2;
            this.tpgSearchStudent.Text = "학생조회";
            this.tpgSearchStudent.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(41, 36);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(192, 56);
            this.label3.TabIndex = 1;
            this.label3.Text = "학번";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tbxRegCourseSearchId
            // 
            this.tbxRegCourseSearchId.Location = new System.Drawing.Point(165, 49);
            this.tbxRegCourseSearchId.Name = "tbxRegCourseSearchId";
            this.tbxRegCourseSearchId.Size = new System.Drawing.Size(247, 35);
            this.tbxRegCourseSearchId.TabIndex = 2;
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(41, 132);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(192, 56);
            this.label4.TabIndex = 3;
            this.label4.Text = "학번";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblRegCourseId
            // 
            this.lblRegCourseId.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblRegCourseId.Location = new System.Drawing.Point(163, 132);
            this.lblRegCourseId.Name = "lblRegCourseId";
            this.lblRegCourseId.Size = new System.Drawing.Size(192, 56);
            this.lblRegCourseId.TabIndex = 4;
            this.lblRegCourseId.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label6
            // 
            this.label6.Location = new System.Drawing.Point(41, 247);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(192, 56);
            this.label6.TabIndex = 5;
            this.label6.Text = "이름";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblRegCourseName
            // 
            this.lblRegCourseName.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblRegCourseName.Location = new System.Drawing.Point(161, 247);
            this.lblRegCourseName.Name = "lblRegCourseName";
            this.lblRegCourseName.Size = new System.Drawing.Size(192, 56);
            this.lblRegCourseName.TabIndex = 6;
            this.lblRegCourseName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label8
            // 
            this.label8.Location = new System.Drawing.Point(41, 365);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(192, 56);
            this.label8.TabIndex = 7;
            this.label8.Text = "이름";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // btnRegCourseSearch
            // 
            this.btnRegCourseSearch.Location = new System.Drawing.Point(461, 44);
            this.btnRegCourseSearch.Name = "btnRegCourseSearch";
            this.btnRegCourseSearch.Size = new System.Drawing.Size(147, 41);
            this.btnRegCourseSearch.TabIndex = 8;
            this.btnRegCourseSearch.Text = "검색";
            this.btnRegCourseSearch.UseVisualStyleBackColor = true;
            this.btnRegCourseSearch.Click += new System.EventHandler(this.btnRegCourseSearch_Click);
            // 
            // lbxRegCourse
            // 
            this.lbxRegCourse.FormattingEnabled = true;
            this.lbxRegCourse.ItemHeight = 24;
            this.lbxRegCourse.Location = new System.Drawing.Point(165, 365);
            this.lbxRegCourse.Name = "lbxRegCourse";
            this.lbxRegCourse.Size = new System.Drawing.Size(247, 148);
            this.lbxRegCourse.TabIndex = 9;
            // 
            // tbxRegCourseName
            // 
            this.tbxRegCourseName.Location = new System.Drawing.Point(165, 543);
            this.tbxRegCourseName.Name = "tbxRegCourseName";
            this.tbxRegCourseName.Size = new System.Drawing.Size(247, 35);
            this.tbxRegCourseName.TabIndex = 10;
            // 
            // btnRegCourseOverriding
            // 
            this.btnRegCourseOverriding.Location = new System.Drawing.Point(688, 538);
            this.btnRegCourseOverriding.Name = "btnRegCourseOverriding";
            this.btnRegCourseOverriding.Size = new System.Drawing.Size(218, 41);
            this.btnRegCourseOverriding.TabIndex = 8;
            this.btnRegCourseOverriding.Text = "등록(오버라이딩)";
            this.btnRegCourseOverriding.UseVisualStyleBackColor = true;
            this.btnRegCourseOverriding.Click += new System.EventHandler(this.btnRegCourseOverriding_Click);
            // 
            // btnRegCourseHiding
            // 
            this.btnRegCourseHiding.Location = new System.Drawing.Point(442, 538);
            this.btnRegCourseHiding.Name = "btnRegCourseHiding";
            this.btnRegCourseHiding.Size = new System.Drawing.Size(202, 41);
            this.btnRegCourseHiding.TabIndex = 8;
            this.btnRegCourseHiding.Text = "등록(하이딩)";
            this.btnRegCourseHiding.UseVisualStyleBackColor = true;
            this.btnRegCourseHiding.Click += new System.EventHandler(this.btnRegCourseHiding_Click);
            // 
            // Form1
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(950, 650);
            this.Controls.Add(this.tabMain);
            this.Font = new System.Drawing.Font("굴림", 9F);
            this.Name = "Form1";
            this.Text = "학생관리";
            this.tabMain.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.pnlEntranceCompany.ResumeLayout(false);
            this.pnlEntranceCompany.PerformLayout();
            this.tpgRegCourse.ResumeLayout(false);
            this.tpgRegCourse.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabMain;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tpgRegCourse;
        private System.Windows.Forms.Label lblEntranceResult;
        private System.Windows.Forms.TabPage tpgSearchStudent;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnEntrance;
        private System.Windows.Forms.Panel pnlEntranceCompany;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label tbxEntranceCompany;
        private System.Windows.Forms.CheckBox chkIndustrialEdu;
        private System.Windows.Forms.TextBox tbxEntranceName;
        private System.Windows.Forms.ComboBox cbxEntranceGrade;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tbxRegCourseName;
        private System.Windows.Forms.ListBox lbxRegCourse;
        private System.Windows.Forms.Button btnRegCourseHiding;
        private System.Windows.Forms.Button btnRegCourseOverriding;
        private System.Windows.Forms.Button btnRegCourseSearch;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label lblRegCourseName;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lblRegCourseId;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tbxRegCourseSearchId;
        private System.Windows.Forms.Label label3;
    }
}

